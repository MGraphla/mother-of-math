import{t as o}from"./en-US-C5vD-bVu.js";function r(t){return+o(t)<Date.now()}export{r as i};
