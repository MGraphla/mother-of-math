const a=r=>(r==null?void 0:r.role)==="teacher",t=r=>(r==null?void 0:r.role)==="parent",P=["Primary 1","Primary 2","Primary 3","Primary 4","Primary 5","Primary 6"];export{P,t as a,a as i};
