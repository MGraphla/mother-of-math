import{s as t}from"./startOfDay-De7tip6N.js";function o(a,r){const s=t(a),e=t(r);return+s==+e}export{o as i};
