import{t as r}from"./en-US-C5vD-bVu.js";function a(o){const t=r(o);return t.setHours(0,0,0,0),t}export{a as s};
