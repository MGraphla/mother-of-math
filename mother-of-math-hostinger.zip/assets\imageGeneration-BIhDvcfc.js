import{g as f}from"./api-BOzGzJ9A.js";const y="google/gemini-3-pro-image-preview",b="https://openrouter.ai/api/v1/chat/completions",v=6e4,k=async(e,h="16:9")=>{var m,l,g,u,d;const n=f(),a=b;if(!n)return console.warn("[ImageGen] No API key available"),null;const i=new AbortController,p=setTimeout(()=>i.abort(),v);try{const r=await fetch(a,{method:"POST",signal:i.signal,headers:{"Content-Type":"application/json",Authorization:`Bearer ${n}`,"HTTP-Referer":window.location.origin,"X-Title":"Mother of Math"},body:JSON.stringify({model:y,messages:[{role:"user",content:e}],modalities:["image","text"],stream:!1,image_config:{aspect_ratio:h,image_size:"1K"}})});if(clearTimeout(p),!r.ok){const c=await r.json().catch(()=>({}));return console.warn("[ImageGen] API error:",r.status,c),null}const o=(l=(m=(await r.json()).choices)==null?void 0:m[0])==null?void 0:l.message;return(d=(u=(g=o==null?void 0:o.images)==null?void 0:g[0])==null?void 0:u.image_url)!=null&&d.url?o.images[0].image_url.url:(console.warn("[ImageGen] No image in response"),null)}catch(r){return clearTimeout(p),r.name==="AbortError"?console.warn("[ImageGen] Request timed out"):console.error("[ImageGen] Error:",r),null}},s=(e,h="section")=>{const n=`Professional, vibrant educational illustration for a premium PowerPoint presentation.
Modern flat vector design with soft gradients and clean rounded shapes.
Primary color palette: rich green (#009e60), warm brown (#4b371c), soft gold/yellow (#F4B400), clean white backgrounds.
Setting: African/Cameroonian elementary school with diverse young Black children.
IMPORTANT: Absolutely NO text, NO words, NO letters, NO numbers, NO writing overlaid on the image. Pure illustration ONLY.
High quality, crisp, polished artwork, suitable as a professional PowerPoint slide image.`;switch(h){case"hero":return`Create a wide, stunning hero cover illustration for a mathematics PowerPoint presentation.
${e}
${n}
Wide panoramic composition (16:9). Vibrant, warm, and extremely inviting. Premium quality educational poster feel.
Include subtle mathematical elements (rulers, geometric shapes, chalk boards) woven naturally into the scene.
Use a lush green and warm brown color scheme to feel natural and African-inspired.`;case"activity":return`Create an illustration showing African children engaged in a hands-on math learning activity.
${e}
${n}
Show students actively collaborating and learning together with a caring teacher. Warm, encouraging classroom atmosphere.
Medium shot composition showing engagement and discovery. Green and brown tones should dominate the palette.`;case"materials":return`Create a beautifully arranged flat-lay or tabletop illustration of mathematics learning materials.
${e}
${n}
Show neatly arranged educational supplies: books, pencils, rulers, counting blocks, shapes, chalk, small chalkboard.
Clean, organized composition. Use green accents and warm brown wooden table/desk surface. Birds-eye or slightly angled view.`;case"evaluation":return`Create an encouraging illustration showing a teacher gently reviewing student work.
${e}
${n}
Show a warm, caring African teacher looking over a child's notebook with a smile. The child looks hopeful.
Include a checkmark or star motif to suggest assessment. Green classroom accents, brown wooden furniture.`;case"celebration":return`Create a joyful, uplifting illustration of African children celebrating a learning achievement.
${e}
${n}
Triumphant, happy atmosphere. Children smiling, clapping, or showing excitement. A proud teacher nearby.
Include subtle mathematical decorative elements. Warm golden lighting with green accents.`;default:return`Create a clean, appealing illustration for an educational presentation slide in an African/Cameroonian school.
${e}
${n}
Professional and visually engaging, suitable for a classroom presentation. Warm green and brown tones.`}},A=async(e,h,n,a)=>{var g,u,d,r;a==null||a("Generating AI images for your presentation...");const i=[{key:"title",prompt:s(`Topic: "${e}" for ${h} students in Cameroon. Show young African children excitedly discovering math concepts in a bright, colorful Cameroonian classroom. The teacher is at the front near a green chalkboard. Include visual representations of the math topic naturally in the scene.`,"hero"),ratio:"16:9"},{key:"objectives",prompt:s(`Cameroonian classroom scene: students raising hands with enthusiasm, eager to learn about "${e}".
A warm, caring female teacher in green attire at the front with a pointer. Bright, motivating learning environment with green walls.`,"section"),ratio:"4:3"},{key:"materials",prompt:s(`Mathematics materials for a lesson about "${e}": textbooks, exercise books, pencils, rulers, counting beads, wooden shapes, a small green chalkboard, chalk, flashcards.
Arranged neatly on a brown wooden desk in a Cameroonian classroom.`,"materials"),ratio:"4:3"}];for(let t=0;t<n.length;t++){const o=n[t],c=((u=(g=o.teacherActivities)==null?void 0:g[0])==null?void 0:u.substring(0,120))||"",w=((r=(d=o.learnerActivities)==null?void 0:d[0])==null?void 0:r.substring(0,120))||"";i.push({key:`section_teacher_${t}`,prompt:s(`Scene showing the TEACHER leading the "${o.title}" phase of a math lesson on "${e}".
The teacher is demonstrating concepts on a green chalkboard or guiding students. ${c?`Activity: ${c}`:""}
Show the teacher actively engaged with the full class in a Cameroonian school.`,"activity"),ratio:"4:3"}),i.push({key:`section_learner_${t}`,prompt:s(`Scene showing young STUDENTS working on the "${o.title}" phase of a "${e}" lesson.
Children collaborating at their desks, writing in notebooks, using manipulatives. ${w?`Activity: ${w}`:""}
Engaged expressions, a warm supportive Cameroonian classroom with green walls.`,"activity"),ratio:"4:3"})}i.push({key:"evaluation",prompt:s(`A caring Cameroonian teacher reviewing the students' math work on "${e}".
She is leaning over a student's desk, smiling encouragingly with a green pen. Other students working at their desks.
Warm assessment scene showing formative evaluation in progress.`,"evaluation"),ratio:"4:3"}),i.push({key:"assignment",prompt:s(`Students excitedly packing their bags with homework notebooks about "${e}".
A teacher is handing out assignment sheets at the classroom door. End-of-lesson energy.
Cameroonian school setting, afternoon light. Green school bags and accessories.`,"section"),ratio:"4:3"}),i.push({key:"closing",prompt:s(`Children celebrating together after completing a successful math lesson on "${e}".
Joyful scene in a Cameroonian school compound. Children high-fiving, clapping, teacher smiling proudly.
Community spirit, warm golden afternoon light. Green school uniforms.`,"celebration"),ratio:"16:9"}),a==null||a(`Generating ${i.length} AI images — this may take a moment...`);const p=await Promise.allSettled(i.map(({key:t,prompt:o,ratio:c})=>k(o,c).then(w=>({key:t,img:w})))),m={};let l=0;for(const t of p)t.status==="fulfilled"&&(m[t.value.key]=t.value.img,t.value.img&&l++);return l>0?a==null||a(`Generated ${l}/${i.length} images successfully!`):a==null||a("Images could not be generated — proceeding with branded slides."),m};export{A as a,k as g};
