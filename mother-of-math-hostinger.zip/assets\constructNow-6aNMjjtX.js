import{c as t}from"./en-US-C5vD-bVu.js";function c(o){return t(o,Date.now())}export{c};
