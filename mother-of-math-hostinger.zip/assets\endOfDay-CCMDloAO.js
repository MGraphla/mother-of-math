import{t as o}from"./en-US-C5vD-bVu.js";function a(e){const t=o(e);return t.setHours(23,59,59,999),t}export{a as e};
