import{c as r}from"./constructNow-6aNMjjtX.js";import{i}from"./isSameDay-FPqY6pkr.js";function a(o){return i(o,r(o))}export{a as i};
