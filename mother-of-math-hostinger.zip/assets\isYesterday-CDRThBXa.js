import{c as s}from"./constructNow-6aNMjjtX.js";import{i as o}from"./isSameDay-FPqY6pkr.js";import{s as i}from"./subDays-BMnfgMUc.js";function c(r){return o(r,i(s(r),1))}export{c as i};
